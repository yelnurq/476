/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.21-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luminakz_47
-- ------------------------------------------------------
-- Server version	10.6.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','$2y$12$UX91eYWjxQl.KGVuNU4TQ.LOI41efI8bNob7AJZJXy7Ztj68scZG6',NULL,'2025-03-28 02:14:49','2025-03-28 02:14:49');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_name` varchar(255) NOT NULL,
  `birth_date` date NOT NULL,
  `grade` tinyint(3) unsigned NOT NULL,
  `parent_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directors`
--

DROP TABLE IF EXISTS `directors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `directors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directors`
--

LOCK TABLES `directors` WRITE;
/*!40000 ALTER TABLE `directors` DISABLE KEYS */;
/*!40000 ALTER TABLE `directors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2024_03_21_182154_create_categories_table',1),(6,'2024_03_21_190253_create_orders_table',1),(7,'2024_05_02_073015_create_shoes_table',1),(8,'2024_05_02_103216_create_admins_table',1),(9,'2024_05_02_153629_create_tags_table',1),(10,'2024_05_02_160709_create_products_table',1),(11,'2024_05_04_132943_create_directors_table',1),(12,'2025_03_27_215808_create_news_table',1),(13,'2025_03_28_180250_create_cache_table',2),(14,'2025_03_28_180312_create_sessions_table',2),(15,'2025_04_09_210230_create_applications_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'14 наурыз - Көрісу күні, осы күннен бастап халқымыз қыстан аман шыққанына қуанып, құттықтап, мерекелейді.','Амал күні қазағым көріседі,\r\nКөрісу, бұл – көненің желісі еді.\r\n\"Жасың құтты болсын!\" деп жамырасып,\r\nАқ ниетпен адал қол беріседі.\r\n\r\nКөріседі – \"Көңілдер жібісін\" деп,\r\nКөріседі – \"Тасысын ырысың!\" деп.\r\nКөріседі – \"Көк мұз да жылысын\" деп,\r\nКөріседі – \"Оң болсын Ұлысың!\" деп.\r\nАмал күні, көрісу күні құтты болсын!???','news_images/UqI2Fj3qMcCKu0E3Tv7KbEvUMwyzuiwQs9DemArP.jpg','2025-03-28 02:15:48','2025-03-28 02:15:48'),(2,'жас ұстаз МУРАТБЕКОВА АҚЕРКЕ НУРЛАНОВНАНЫ құттықтаймыз!','ҚР Оқу-ағарту министрлігінің «Дарын» РҒПО а. ж. 15-16 наурызы аралығында Алматы қаласында ұйымдастырған «Дарынды балаларға талантты ұстаз» республикалық педагогикалық олимпиада қорытындысы бойынша «Жас педагог» секциясына қатысып, республикалық кезеңде ? ІІІ орынды жеңіп алған ағылшын тілі пәнінің мұғалімі, жас ұстаз МУРАТБЕКОВА АҚЕРКЕ НУРЛАНОВНАНЫ құттықтаймыз!\r\nАлар асуыңыз биік болсын! Шығармашылық табыс тілейміз! ???','news_images/mOClCkvJYGBOu4WTdph2TQwnJBdORdvl66ZwYWEJ.jpg','2025-03-28 02:16:41','2025-03-28 02:16:41'),(3,'Ахмет Байтұрсынұлы атындағы №47 жалпы орта білім беретін мектептің 5 \"Ә\" сынып оқушысы 32 келі салмақ дәрежесінде','КУРЧАТОВ қаласында 14-15 наурыз күндері өткен ДЗЮДО күресінен 2010-2011,2012-2013,2014-2015 жылы туылған жасөспірім ұлдар арасында Ұлы Отан соғысынлағы Жеңістің 80 жылдығына арналған дзюдо күресінен Курчатов қаласының ашық біріншілігінде Ахмет Байтұрсынұлы атындағы №47 жалпы орта білім беретін мектептің 5 \"Ә\" сынып оқушысы 32 келі салмақ дәрежесінде\r\nҒалымджанов Дархан?орын 1\"Ә\" сынып оқушысы 23 келі салмақ дәрежесінде\r\nҒалымджанов Досхан ?\r\nорынды иеленді ҚҰТТЫҚТАЙМЫЗ ???\r\nҮйірме жетекшілері:\r\nОрынбеков Дамир Галимджанович\r\nХамитов Азат Серикханович','news_images/B3QLhCg0WP9QPcEvx8AYZ3B9jB8dAZZbRSsfIJbI.jpg','2025-03-28 02:17:20','2025-03-28 02:17:20'),(4,'22 наурыз мерекесіне арналған \"Қош келдің, әз Наурыз!\" тақырыбында өткізілген мерекелік іс-шара.','22 наурыз мерекесіне арналған \"Қош келдің, әз Наурыз!\" тақырыбында өткізілген мерекелік іс-шара. 6 \"А\" сыныбы. Сынып жетекшісі: Газезова Семейгуль Абдировна.','news_images/wul4IrMwcdP2dz5arUD3UOivgVsslanaETGGe0CJ.jpg','2025-03-28 02:17:50','2025-03-28 02:17:50');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `cart` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`cart`)),
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `tag_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_tag_id_foreign` (`tag_id`),
  CONSTRAINT `products_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1U56SZmTCoktG6RiIxlBzKO6twF0K0kcbA6GqUXX',NULL,'18.234.239.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 YaBrowser/25.2.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoielJwYm43NzJJcDlBU0Vhekt1MjJNVmVqTjQ4WGd2WlFOOTNrdVplaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696774),('2dv9BxGRMiUdaYnLgCQdzc4QAOyTbA1pCax2jtEg',NULL,'80.82.63.98','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 SberBrowser/26.0.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSjViRHBERUJwQzR2NGl1UnhCWUppeGNTSDZnOGlucXVtbk8wcG40YiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696789),('3AZ3E7KWTal4QcVy6NOcEAYTNLozyTxABg88NsX4',NULL,'5.255.231.175','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoidGhGbGJNeGZQTTZYZGVuYzM2bWxQU1dEc2pqWVNueVVrbDFRYXVIWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746697288),('73VpG2RLU4mcM14ojyTC94jyhgckk0EyBBB7kAf2',NULL,'141.8.143.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT2lqeW92cXlYd3o2OGRtZXNpOEd5WGZSUTFZQ2NZV3hYUVluRFJxayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696711),('aDZv192BwB1mI4vuk4SrnULyXq8CEiP2Zx66EKbE',NULL,'87.250.224.112','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVB5cmRTNm93SDB1d1I1WWFJRHAzWWtuS2t0bXFnWlJUOVZ0c1B0VCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vNDcubHVtaW5hLmt6L3F1ZXN0aW9ucyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696757),('AzdOmyo2KoZoT0891gQn2MNbOTaO4wn1i51F3kbA',NULL,'5.255.231.23','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoicEFkRnFjejAyclp3UFd1ZVo3cG9nblRncHBtVUNmOUFmQnBrVEczQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2RvY3MvMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696757),('DetgeumWIQOOzjvFoPStXL4j2GoEbpJRzFx6bycT',NULL,'31.56.240.146','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 SberBrowser/25.0.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiS3N6Z0VuUWNUeEs2dE1WZU5CRjBzVTdsYWlXVEloU25heFJFRnBHaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696776),('dgjHIJyoX4Xo2KaqKZ0DcHJ24L4MF4b9gKJdj8Ib',NULL,'213.180.203.161','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVJITnpBdllFN0cwY3VFak1VUlZVSTEzcVU2Z044b0ppUHN1ckpJaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2RvY3MvMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696758),('ee8WfAFVu8jsIrGXmDjLM31WBSsIFCOtwN4PgWqC',NULL,'95.108.213.125','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoianR5VXlWNjdqSXY0bmc0ekM3eHQ0ZXhLekNVUks2TjRsSEpSS2VicCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2Fib3V0L3RlYWNoZXJzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696760),('eMWBO8zOOy6m7sEMxZixY2yUEq0EX9fXtXjHeun4',NULL,'87.250.224.217','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjA3YWFkcExTTXRUdmRlRXkyQk9yY09BdXNOUloxUlFXM29TbFBUViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2FwcGxpY2F0aW9uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746697225),('fYWzG06qt1F5ExDRKrc1Ly1Dv9rxHWyHnftbJsxm',NULL,'213.180.203.173','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoidUdoS2M3a2lpOEJFVEJFc2xqVUZQQkRWQmZjOTNicUhwN21aSVBXRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2FkbWluL2NyZWF0ZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746697223),('GCHoNeRthl1WSaLuMqQV348yBaU37Ox5kxNKbtmB',NULL,'77.88.9.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMENKUmxtelBMYUgyaFV5VmdySktKTWkwSjZYeXZYZFhBSW1kNkVPUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696711),('ifdTMgWcIdV4jqCEii9k1XDUhE2f2ymJBEceECKR',NULL,'87.250.224.52','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibXFMU0hUa3Q4ZDg5S1FJaGFzVWJid2xHN2dPcTA2RUxYZU92SWJneCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2RvY3MvMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746697225),('J6WEQLiSkc1rBsrXJyz5aXGqylySOojIuhVdw6w2',NULL,'87.250.224.105','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibkFJUzRES1ZSenFRdTM1aG9qTmNucGNPeWp5d3lYd0ZXRkZ6d2doRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2FkbWluL2NyZWF0ZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696760),('jJ0yaRTwItcMM2rAWFS9sxubTPzcJowYvJzN6goA',NULL,'87.250.224.97','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibnF1aHhjMkdXdGNsRVNZdXBHRzhIcVdIYkFOazVuVFFndDlMSE1nUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2Fib3V0L2hpc3RvcnkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746697226),('KJRsoe74sFfaCyv4oE52NcRwzNMCngjvlJSfpM3n',NULL,'92.47.86.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEptcG9lV0QxVEJWSjFwRFk5NTVzVEd1R09JMVFlRHVWTTUwQWw0SyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746713312),('kmY99q27MH6vGCVSdBrpY5BbhNdwT5jFGWOC48Go',NULL,'213.180.203.203','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoieHFXTlplZEk3Ukhsb3lRWENLaHlxc3c3MVJlbHJPMWN1MmJzWGU4aiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MvNCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696839),('likIICce0ZbcyBhbHt1jPkigL0Zd6KGJ7xIPI9gJ',NULL,'87.250.224.105','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDVnZDBkRzN6UkxzN3lONkJyb2ZWYzlzSzB1U0F5NmRRTThuZldHbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2RvY3MvMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746697192),('mJfHYhyWGfufCQJTvdwIutgYuTUqTClQHG363AxW',NULL,'5.255.231.175','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiS3BsMXRXOTJBdmFlaGRkb0dWYlhjZzRTS1hrYXlHSmRzTUlKNFVSSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MvMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696841),('mpei8Bbx8qQxLRitw54ZPeZQc3Z8EX37aynPyK9j',NULL,'87.250.224.105','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoieDBVSXR4NGk2YzZOWmlkWG5NMkY3cmFhajROV2t2ZHVoM1Vrdm04bCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vNDcubHVtaW5hLmt6L3N1cHBvcnQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746696761),('mRUAnD5iqTtSCC1qzGhjOFKg4nESyDGSPjkJCh5H',NULL,'77.88.47.20','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmN3OVhHS2dHaVY1a2JvbWh2RzhhamFCRmE4cmVvUlJJVnZRRlZLbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696711),('pbSBXpyt0UPoqSZgbrFyeztfRuupjKV8Zeo4SiOg',NULL,'87.250.233.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibXMwNE9iZFB6ejBMQ1c3eUNwS0sxS1lIa3NOcExLSzdlelZFSm1TNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696712),('pbVZ89pEWjFLXCbhGNr42cjBQCz994WXid6Eg4nC',NULL,'213.180.203.173','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQW92NVBOUHI0c0V3YjFvcGczbm9FMWxVeGR6dHZXVG1TeXIzQ28zWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2FwcGxpY2F0aW9uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696760),('pFvssy76UU78lq16A0VaYpZ13GlDqqrQ1CRwFxEv',NULL,'95.108.213.90','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXFrWUxmMzRSUFpDbFRIS1RTRnoxd1VwS0h5NmxmQlNVQ3JtemFQayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vNDcubHVtaW5hLmt6L3F1ZXN0aW9ucyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746697224),('Pjmg6c2jQK9WWsHKfG2KMaLGLg9ijm5igD44Up6X',NULL,'213.180.203.236','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoidTBvV0hqUVlYWWZ5SjJDM1N2cGU1OVBRcUwzUkFaTGNxS0hHZlpzdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2FkbWluIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696761),('pVFZmpBL30cu4Si06My1OltYRFckgiP9ZK7wOTSu',NULL,'213.180.203.216','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN1o4allBU1ZLYWhTajRVWmEzb2NPWWJKYTV2NjhQMkllUGNGVTRjbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2Fib3V0L3RlYWNoZXJzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746697222),('pVUeW5VvlraoiN0oNG6qSUrphdDcZQt59orQTtxu',NULL,'38.54.105.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDRhSjVMeVhybkRzR1hOZTc5NnBmQkttUWV0eDhtOWdIdzl1bEFqdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696735),('qIiBbojh65j4bQSGr2w26olIByF7Yu7siWteHoE5',NULL,'213.180.203.185','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVGlPS0VlSXZ6dUlGa0NGbVAxTG5BNnN2MEM1bFRqVGpFcHlwV0lIbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2Fib3V0L2FkbWluaXN0cmF0aW9uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746697224),('qwTeWwhz28QigftdIs2YNu7oUQyPjPS1spOlP1Nj',NULL,'213.180.203.111','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSDhjSGZHWnk2U1lIREpGOThzY3dVcjVZVXpLN1Q0dFpkaGhObklmNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746696759),('qXwt7JfQuMqwGTmKhnYefCaqYFPTzu0y4Y80IbWP',NULL,'95.108.213.135','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGp4YkRCTzlRdVN1ejBvbm5ma2JqTm41Zml2ZU1RZFk4SlMxaUpGVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2RvY3MvMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696758),('rLU8fFUhmcIy3cAlTFFUNzoufMVFxrWi2HaB3cmQ',NULL,'5.255.251.137','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoicHNmcVRkdE5icFE4N0JvMzlHUWxRZzBneTlGVHdKVDQ0WU9qSEJ2MCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696711),('rUDy1BLVtMYLi2eh0YDaqI7j2PfFF9xp83gTJ4HX',NULL,'5.255.231.125','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiekV5RmJ1aGFyTWRTd0hmR0F3NHVwR1JyeGJNcEsyaXdlTEtQRzRYUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2JhaWxhbnlzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696759),('S2MLhlZgemUT7g392OTcTawnXacDdun366QWFZIt',NULL,'87.250.224.8','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0ZQdWUxN0dZb2s2WFhUcWRRUk9GUHNqY3JWd0R1R1daOVBaZHQ2OSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696712),('SBF75R9axCkye4N9aqaDpeIfuCdMsNhgxXXff6Ec',NULL,'5.255.231.75','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVlwSkVIbFlHR2plbjBNcjM1WkhQWWdJRTZIZE9kenpPS2Z1cGdSSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2RvY3MvMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746697226),('SN8kGI9x0nk6avvTWbZScV5CJxMOWpgcyZJbMJGF',NULL,'213.180.203.203','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiS2R2M1VZNE5Mek9TdUt6SGxkOU1EeWVCVDREZDY4ZnVDczczMjRyTSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2FkbWluIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746697224),('tHm9s9910woLqG7wRrhS6OtfhbQKJtFPEeraE3bg',NULL,'95.108.213.79','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkNnWkxtSUNjdjZjSnp1Z0pXUms3V21pTE1yWlhiQzFUZ1Y2SEJMTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2JhaWxhbnlzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746697224),('v1j2kctt9ua4zSFM6igKtUlSW4C8BKYmqgUIXXgp',NULL,'213.180.203.45','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlEydGJCZjNsaG1PUUIwRDlBakF4cWE3SXhuRGVpWG9lVGFVWU5pYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MvMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696838),('wP4LSavMFqBgiC3kdi25xCGDh4UGIm48snRH0Umh',NULL,'87.250.224.215','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUUwdjZxOXJZNGpHNFJGOEZkUmZad0V1ZDV6OE13cGFPdnlHVzdxWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vNDcubHVtaW5hLmt6L3N1cHBvcnQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746697225),('x7WhLTFa3q8bpANvHuH34ZBQEo7CGBd3gcIFvP0i',NULL,'95.108.213.79','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkg3NHp6UGlLcjZpNW01UU5TZ3dtRHNEb1p4ZHV3b1pNdm01R2lWVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2Fib3V0L2FkbWluaXN0cmF0aW9uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696760),('xIsgLJh4sXihb7iw8lIJGVLAwyaFhlBEaSOKQTbI',NULL,'95.108.213.211','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoidGRQMUVGMzdFUVRXaFNKeTNSNkNhWHJla2Q3Mk9iOTNsWEplVWRNbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vNDcubHVtaW5hLmt6L25ld3MvMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746696837),('y4sXbDXE1hSfDa8OYKbuCE2B316WjP69xU0uFdFq',NULL,'213.180.203.182','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUmVJbU9PTVZjTDZlWnV1SlM5SjdIT1ZITXNVT2VTaUk5dm9BMmFKeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vNDcubHVtaW5hLmt6L2Fib3V0L2hpc3RvcnkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746696760),('z8OrK4YkOgA91FyTeoaNaFSdkgJOTIpoA9iUM1Jn',NULL,'87.250.224.217','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWt6SlZSelh5QXp6QmZkVGkyVE5OUWJ0ZkZLcWU4ekxldVRjTzZCSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vNDcubHVtaW5hLmt6Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746696839);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shoes`
--

DROP TABLE IF EXISTS `shoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shoes`
--

LOCK TABLES `shoes` WRITE;
/*!40000 ALTER TABLE `shoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `shoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'luminakz_47'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-08 19:08:50
